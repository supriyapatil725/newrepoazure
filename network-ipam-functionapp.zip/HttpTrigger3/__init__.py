import logging
import json
import requests

import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    url = "http://20.121.49.195/api/vnetfactory/user/"
    response = requests.request("POST", url , auth=("admin", "phpadmin"), verify=False)
    response = json.loads(response.content)
    print(response)
    token = response['data']['token']
    dict1 = dict()
    dict1['name'] = "rajat"
    dict1['cidr'] = "10.1.0.0/24"
    resultset = json.dumps(dict1)
    return func.HttpResponse(
            resultset,
            status_code=200
    )
