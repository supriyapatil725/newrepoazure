import logging

import azure.functions as func
from azure.identity import AzureCliCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.storage import StorageManagementClient
import random

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    credential = AzureCliCredential()
    print(credential)
    print("Hello Identity")

    subscription_id = "30bd0373-7a26-4108-9ab9-bc53b741cc87"
    resource_client = ResourceManagementClient(credential, subscription_id)
    RESOURCE_GROUP_NAME = "ExampleGroup"
    LOCATION = "centralus"
    storage_client = StorageManagementClient(credential, subscription_id)
    STORAGE_ACCOUNT_NAME = f"pythonazurestorage{random.randint(1,100000):05}"
    poller = storage_client.storage_accounts.begin_create(RESOURCE_GROUP_NAME, STORAGE_ACCOUNT_NAME,
    {
        "location" : LOCATION,
        "kind": "StorageV2",
        "sku": {"name": "Standard_LRS"}
    })
    if name:
        return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
             status_code=200
        )
    

