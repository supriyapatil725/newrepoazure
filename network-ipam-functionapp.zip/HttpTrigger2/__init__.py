import logging
import requests
import json
import os
import sys
import traceback
import azure.functions as func
from . import php

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    
    try:
        project_name = os.environ['ProjectName']
        region = os.environ['Region']
        app_id = os.environ['AppId']
    except Exception as e:
        exception_type, exception_value, exception_traceback = sys.exc_info()
        traceback_string = traceback.format_exception(exception_type, exception_value, exception_traceback)
        err_msg = json.dumps({
            "errorType": exception_type.__name__,
            "errorMessage": str(exception_value),
            "stackTrace": traceback_string
        })
        logger.error(err_msg)
        return func.HttpResponse(
                    "{'message': 'Azue function failed'}",
                    status_code=500
                )                    


    try:
        resp = php.main(req, project_name, app_id)
        print("success!!")
        if resp == "error":
            return func.HttpResponse(
                        "{'message': 'Azue function failed'}",
                        status_code=500
                    )
        else:            
            return func.HttpResponse(
                    "{'$schema': 'https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#', 'contentVersion': '1.0.0.0', 'parameters': {}, 'variables': {}, 'resources': []}",
                    status_code=200
            )
    except Exception as e:
        exception_type, exception_value, exception_traceback = sys.exc_info()
        traceback_string = traceback.format_exception(exception_type, exception_value, exception_traceback)
        err_msg = json.dumps({
            "errorType": exception_type.__name__,
            "errorMessage": str(exception_value),
            "stackTrace": traceback_string
        })
        logger.error(err_msg)
        return func.HttpResponse(
                    "{'message': 'Azue function failed'}",
                    status_code=500
                )    
