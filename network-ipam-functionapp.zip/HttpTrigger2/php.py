import os
import json
import traceback
import logging
import sys
import requests
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def delete_network_section(token,ipam_server,app_id,request_network_section_name):
    print("Delete the Section in case of Failure")
    payload = {}
    url = "http://{}/api/{}/sections/{}/".format(ipam_server,app_id,request_network_section_name)
    response = requests.request("GET", url, headers={'token': token}, json=payload, verify=False)
    response = json.loads(response.text)
    id = response['data']['id']
    payload = {}
    url = "http://{}/api/{}/sections/{}/".format(ipam_server,app_id,id)
    response = requests.request("DELETE", url, headers={'token': token}, json=payload, verify=False)

def main(req, project_name, app_id):

    # Get the Event Values
    try:
        req = req.get_json()
        print("Request: {}".format(req))
        event_region = req.get('Region')
        ipam_server=req.get('IPAMServerIP')
        username=req.get('IPAMServerUsername')
        password=req.get('IPAMServerPassword')
        nw_regional_cidr_list=req.get('RegionalCidrListForNetworkSegment')
        nw_name=req.get('NetworkSegmentName')
        print("Event Region: {}".format(event_region))
    except Exception as e:
        exception_type, exception_value, exception_traceback = sys.exc_info()
        traceback_string = traceback.format_exception(exception_type, exception_value, exception_traceback)
        err_msg = json.dumps({
            "errorType": exception_type.__name__,
            "errorMessage": str(exception_value),
            "stackTrace": traceback_string
        })
        logger.error(err_msg)
        return "error"

    # Get the Authentication Token from PHP IPAM server
    try:
        url = "http://{}/api/{}/user/".format(ipam_server,app_id)
        response = requests.request("POST", url , auth=(username, password), verify=False)
        if response.status_code not in range(200,204):
            print("Response Status: {}".format(response.status_code))
            print(response.text)
            print("REST API error while generating an Authentication Token from PHP IPAM Server. Please check.")
            return
        response = json.loads(response.content)
        print(response)
        token = response['data']['token']
    
        # Build the Section Name for creating a Section in PHP IPAM serve
        request_network_section_name = "{}_{}_{}_regional_cidr".format(project_name,nw_name,event_region)
        section_description = "Regional CIDR for {}".format(event_region)
    except Exception as e:
        exception_type, exception_value, exception_traceback = sys.exc_info()
        traceback_string = traceback.format_exception(exception_type, exception_value, exception_traceback)
        err_msg = json.dumps({
            "errorType": exception_type.__name__,
            "errorMessage": str(exception_value),
            "stackTrace": traceback_string
        })
        logger.error(err_msg)
        return "error"

    #### CREATE EVENT ####
    try:
        # Create a Network Section in the PHP IPAM Server
        payload = {"name":request_network_section_name,"description":section_description}
        url = "http://{}/api/{}/sections/".format(ipam_server,app_id)
        response = requests.request("POST", url, headers={'token': token}, json=payload, verify=False)
        if response.status_code not in range(200,204):
            print("Response Status: {}".format(response.status_code))
            print(response.text)
            print("REST API error while creating a Network Section in PHP IPAM server. Please check.")
            delete_network_section(token,ipam_server,app_id,request_network_section_name)
            return "error"
        print(response.text)
        print("Network Section with the name {} created in the IPAM instance.".format(request_network_section_name))
        
        # Get the Section ID
        response = json.loads(response.text)
        section_id = response['id']
            
        # Add a Super Network to the Network Section in PHP IPAM Server
        nw_regional_cidr_list = nw_regional_cidr_list.split(',')
        for i in range(len(nw_regional_cidr_list)):
            a,b = nw_regional_cidr_list[i].split('/')
            payload = {"subnet":a, "mask":b, "sectionId":section_id}
            url = "http://{}/api/{}/subnets/".format(ipam_server,app_id)
            response = requests.request("POST", url, headers={'token': token}, json=payload, verify=False) 
            print(response.text)
            if response.status_code not in range(200,204):
                print("Response Status: {}".format(response.status_code))
                print("REST API error while adding a super net in the PHP IPAM server. Please check.")
                delete_network_section(token,ipam_server,app_id,request_network_section_name)
                return "error"
            print("Super Network {} added to the Network Section {}".format(nw_regional_cidr_list[i],request_network_section_name))
        return request_network_section_name
    except Exception:
        exception_type, exception_value, exception_traceback = sys.exc_info()
        traceback_string = traceback.format_exception(exception_type, exception_value, exception_traceback)
        err_msg = json.dumps({
            "errorType": exception_type.__name__,
            "errorMessage": str(exception_value),
            "stackTrace": traceback_string
        })
        logger.error(err_msg)
        return "error"        